---
layout: default
title: ThemePacks HOWTO
---

ThemePacks HOWTO
================

Themes (Theme Packs) For Window Maker
-------------------------------------
**Note:** the information contained in this file is only valid for themes in the
.themed (for theme directory) format, supported in Window Maker 0.50.0 or newer.
See [here](theme-HOWTO.html) for information on themes for WindowMaker-0.20.3
and earlier.

How To Install a Theme Pack
---------------------------
To install a theme, unpack your theme into your WindowMaker directory (the same
as old-style themes), usually `~/GNUstep/Library/WindowMaker`

    cd ~/GNUstep/Library/WindowMaker
    gzip -dc "xyztheme.tar.gz" | tar xvf -

You can also do this in your system-wide WindowMaker directory (usually
`/usr/local/share/WindowMaker`) to have the themes be available to all your
users. This will probably need to be done with root access.

How To Load a Theme
-------------------
After installing a theme, it will automatically show up in your menu under
**Appearance -> Themes -> ThemeName**. (unless of course you have manually
changed your menu to remove this) If you have your Themes menu already opened
and pinned to your desktop, you may need to close it and reopen it to have it
show the new theme.

To manually load the new theme from the command line, use the `setstyle`
command. Example:

    setstyle xyztheme.themed

Note that if you move the directory of the theme (for example, from
`~/GNUstep/Library/WindowMaker/Themes` to `/usr/local/share/WindowMaker/Themes`)
you will have to reload that theme so that path information is updated.

How To Make a Theme Pack
------------------------
To create a theme pack from your current configuration, use the `getstyle`
utility with the `-p` flag. Example:

    getstyle -p ~/GNUstep/Library/WindowMaker/Themes/MyTheme

This will create a theme pack (a new directory in either the current directory
or a directory you specify) named `MyTheme.themed`, containing everything it
requires, including all pixmap files. In this example, the new theme pack would
be made in your themes directory and be immediately available in your "Themes"
menu.

Additionally, you can put a text file named `MyTheme.lsm` in the MyTheme.themed
directory. This file can contain info like copyrights, credits or whatever.

To distribute your theme, just make a .tar.gz of the `.themed` directory. This
is preferably done from the same directory that you unpack the themes from to
maintain consistancy with the old theme format.

Example:

    cd ~/GNUstep/Library/WindowMaker
    tar cvf MyTheme.tar Themes/MyTheme.themed
    gzip MyTheme.tar

How To Delete a Theme Pack
--------------------------
Just remove the .themed directory. Example:

    cd ~/GNUstep/Library/WindowMaker/Themes
    rm -fr themename.themed

How To Save Disk Space
----------------------
If you have more than 1 theme that use the same huge background image, you can
delete all the duplicated files and then create hard links in place of them. For
example, if you have:

    theme1.themed/back.jpg
    theme2.themed/backimage.jpg
    theme3.themed/back.jpg

and all three files contain the same image, you can do:

    rm theme2.themed/backimage.jpg
    rm theme3.themed/back.jpg
    ln theme1.themed/back.jpg theme2.themed/backimage.jpg
    ln theme1.themed/back.jpg theme3.themed/back.jpg
